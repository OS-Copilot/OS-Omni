"""Shared core package."""

