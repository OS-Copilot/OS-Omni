"""iOS evaluator package."""
