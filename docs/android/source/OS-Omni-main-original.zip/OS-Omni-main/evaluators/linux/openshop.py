"""API-backed evaluator for the OpenShop shopping desktop app."""

from __future__ import annotations

import json
from typing import Any, Mapping

from core.evaluation import BaseEvaluator, EvalResult, EvalStatus


class OpenShopApiEvaluator(BaseEvaluator):
    """Validate session, cart, and order state through OpenShop's local API."""

    DEFAULT_PORT = 4310

    def evaluate(self, context: Mapping[str, Any]) -> EvalResult:
        controller = context.get("controller")
        if controller is None or not hasattr(controller, "run_bash_script"):
            return EvalResult(status=EvalStatus.ERROR, message="controller.run_bash_script is required")

        params = dict(context.get("params") or {})
        port = int(params.get("port", self.DEFAULT_PORT) or self.DEFAULT_PORT)
        timeout = int(params.get("timeout", 15) or 15)

        try:
            metadata: dict[str, Any] = {}
            if isinstance(params.get("session"), Mapping):
                session_payload = self._fetch_json(controller, f"/api/session", port=port, timeout=timeout)
                metadata["session"] = session_payload
                self._validate_session(dict(params["session"]), session_payload)

            if isinstance(params.get("cart"), Mapping):
                cart_payload = self._fetch_json(controller, f"/api/cart", port=port, timeout=timeout)
                metadata["cart"] = cart_payload
                self._validate_cart(dict(params["cart"]), cart_payload)

            if isinstance(params.get("orders"), Mapping):
                orders_payload = self._fetch_json(controller, f"/api/orders", port=port, timeout=timeout)
                metadata["orders"] = orders_payload
                self._validate_orders(dict(params["orders"]), orders_payload)

            if isinstance(params.get("benchmark_events"), list):
                benchmark_payload = self._fetch_json(controller, f"/api/benchmark", port=port, timeout=timeout)
                metadata["benchmark"] = benchmark_payload
                self._validate_benchmark_events(list(params["benchmark_events"]), benchmark_payload)

            if isinstance(params.get("benchmark_event_sequence"), list):
                benchmark_payload = metadata.get("benchmark") or self._fetch_json(controller, f"/api/benchmark", port=port, timeout=timeout)
                metadata["benchmark"] = benchmark_payload
                self._validate_benchmark_event_sequence(list(params["benchmark_event_sequence"]), benchmark_payload)

            if isinstance(params.get("text_artifacts"), list):
                metadata["text_artifacts"] = self._validate_text_artifacts(
                    controller,
                    list(params["text_artifacts"]),
                    timeout=timeout,
                )
        except AssertionError as exc:
            return EvalResult(status=EvalStatus.FAIL, message=str(exc), metadata=metadata if "metadata" in locals() else {})
        except Exception as exc:
            return EvalResult(status=EvalStatus.ERROR, message=f"OpenShop API evaluation failed: {exc}")

        return EvalResult(status=EvalStatus.PASS, message="OpenShop API evaluation passed", metadata=metadata)

    @staticmethod
    def _fetch_json(controller: Any, path: str, *, port: int, timeout: int) -> Mapping[str, Any]:
        script = f"""python3 - <<'PY'
import json
import urllib.request

with urllib.request.urlopen("http://127.0.0.1:{port}{path}", timeout={timeout}) as resp:
    body = resp.read().decode("utf-8")
    print(body)
PY"""
        result = controller.run_bash_script(script, timeout=timeout + 5)
        returncode = int(result.get("returncode", -1))
        output = str(result.get("output", "")).strip()
        if returncode != 0:
            detail = output or f"guest command failed with exit code {returncode}"
            raise RuntimeError(f"{path}: {detail}")
        try:
            return json.loads(output)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"guest API response was not valid JSON: {exc}: {output}") from exc

    @staticmethod
    def _validate_session(expectation: Mapping[str, Any], payload: Mapping[str, Any]) -> None:
        session = dict(payload.get("session") or {})
        if "logged_in" in expectation:
            actual = bool(session.get("loggedIn"))
            expected = bool(expectation.get("logged_in"))
            assert actual == expected, f"expected session.loggedIn={expected}, got {actual}"
        if "phone" in expectation:
            actual_phone = str((session.get("user") or {}).get("phone") or "")
            expected_phone = str(expectation.get("phone") or "")
            assert actual_phone == expected_phone, f"expected session.user.phone={expected_phone}, got {actual_phone}"
        if "user_name" in expectation:
            actual_name = str((session.get("user") or {}).get("name") or "")
            expected_name = str(expectation.get("user_name") or "")
            assert actual_name == expected_name, f"expected session.user.name={expected_name}, got {actual_name}"

    @staticmethod
    def _validate_cart(expectation: Mapping[str, Any], payload: Mapping[str, Any]) -> None:
        items = list(payload.get("items") or [])
        if "item_count" in expectation:
            expected_count = int(expectation.get("item_count") or 0)
            assert len(items) == expected_count, f"expected {expected_count} cart items, got {len(items)}"
        if "subtotal" in expectation:
            actual_subtotal = float(payload.get("subtotal") or 0)
            expected_subtotal = float(expectation.get("subtotal") or 0)
            assert actual_subtotal == expected_subtotal, (
                f"expected cart subtotal {expected_subtotal}, got {actual_subtotal}"
            )
        if "shipping" in expectation:
            actual_shipping = float(payload.get("shipping") or 0)
            expected_shipping = float(expectation.get("shipping") or 0)
            assert actual_shipping == expected_shipping, (
                f"expected cart shipping {expected_shipping}, got {actual_shipping}"
            )
        if "discount" in expectation:
            actual_discount = float(payload.get("discount") or 0)
            expected_discount = float(expectation.get("discount") or 0)
            assert actual_discount == expected_discount, (
                f"expected cart discount {expected_discount}, got {actual_discount}"
            )
        if "total" in expectation:
            actual_total = float(payload.get("total") or 0)
            expected_total = float(expectation.get("total") or 0)
            assert actual_total == expected_total, f"expected cart total {expected_total}, got {actual_total}"

        for expected_item in expectation.get("items") or []:
            if not isinstance(expected_item, Mapping):
                continue
            product_id = str(expected_item.get("product_id") or expected_item.get("productId") or "")
            match = next((item for item in items if str(((item.get("product") or {}).get("id") or "")) == product_id), None)
            assert match is not None, f"expected cart item with product_id={product_id}"
            if "quantity" in expected_item:
                actual_quantity = int(match.get("quantity") or 0)
                expected_quantity = int(expected_item.get("quantity") or 0)
                assert actual_quantity == expected_quantity, (
                    f"expected cart quantity {expected_quantity} for product {product_id}, got {actual_quantity}"
                )
            if "selected_spec" in expected_item:
                actual_spec = str(match.get("selectedSpec") or "")
                expected_spec = str(expected_item.get("selected_spec") or "")
                assert actual_spec == expected_spec, (
                    f"expected cart selectedSpec={expected_spec} for product {product_id}, got {actual_spec}"
                )

    @staticmethod
    def _validate_orders(expectation: Mapping[str, Any], payload: Mapping[str, Any]) -> None:
        orders = list(payload.get("orders") or [])
        if "count" in expectation:
            expected_count = int(expectation.get("count") or 0)
            assert len(orders) == expected_count, f"expected {expected_count} orders, got {len(orders)}"

        latest_expectation = expectation.get("latest")
        if not isinstance(latest_expectation, Mapping):
            return
        assert orders, "expected at least one order, got none"

        latest_order = dict(orders[0] or {})
        if "status" in latest_expectation:
            actual_status = str(latest_order.get("status") or "")
            expected_status = str(latest_expectation.get("status") or "")
            assert actual_status == expected_status, f"expected latest order status={expected_status}, got {actual_status}"
        if "note" in latest_expectation:
            actual_note = str(latest_order.get("note") or "")
            expected_note = str(latest_expectation.get("note") or "")
            assert actual_note == expected_note, f"expected latest order note={expected_note}, got {actual_note}"
        if "total" in latest_expectation:
            actual_total = float(latest_order.get("total") or 0)
            expected_total = float(latest_expectation.get("total") or 0)
            assert actual_total == expected_total, f"expected latest order total={expected_total}, got {actual_total}"
        if "address_label" in latest_expectation:
            actual_label = str((latest_order.get("address") or {}).get("label") or "")
            expected_label = str(latest_expectation.get("address_label") or "")
            assert actual_label == expected_label, (
                f"expected latest order address.label={expected_label}, got {actual_label}"
            )
        if "address_receiver" in latest_expectation:
            actual_receiver = str((latest_order.get("address") or {}).get("receiver") or "")
            expected_receiver = str(latest_expectation.get("address_receiver") or "")
            assert actual_receiver == expected_receiver, (
                f"expected latest order address.receiver={expected_receiver}, got {actual_receiver}"
            )
        if "address_full" in latest_expectation:
            actual_full = str((latest_order.get("address") or {}).get("fullAddress") or "")
            expected_full = str(latest_expectation.get("address_full") or "")
            assert actual_full == expected_full, (
                f"expected latest order address.fullAddress={expected_full}, got {actual_full}"
            )
        if "payment_id" in latest_expectation:
            actual_payment_id = str((latest_order.get("payment") or {}).get("id") or "")
            expected_payment_id = str(latest_expectation.get("payment_id") or "")
            assert actual_payment_id == expected_payment_id, (
                f"expected latest order payment.id={expected_payment_id}, got {actual_payment_id}"
            )
        if "payment_label" in latest_expectation:
            actual_payment_label = str((latest_order.get("payment") or {}).get("label") or "")
            expected_payment_label = str(latest_expectation.get("payment_label") or "")
            assert actual_payment_label == expected_payment_label, (
                f"expected latest order payment.label={expected_payment_label}, got {actual_payment_label}"
            )
        if "payment_desc" in latest_expectation:
            actual_payment_desc = str((latest_order.get("payment") or {}).get("desc") or "")
            expected_payment_desc = str(latest_expectation.get("payment_desc") or "")
            assert actual_payment_desc == expected_payment_desc, (
                f"expected latest order payment.desc={expected_payment_desc}, got {actual_payment_desc}"
            )
        if "item_count" in latest_expectation:
            expected_item_count = int(latest_expectation.get("item_count") or 0)
            actual_item_count = len(latest_order.get("items") or [])
            assert actual_item_count == expected_item_count, (
                f"expected latest order item_count={expected_item_count}, got {actual_item_count}"
            )

        order_items = list(latest_order.get("items") or [])
        for expected_item in latest_expectation.get("items") or []:
            if not isinstance(expected_item, Mapping):
                continue
            product_id = str(expected_item.get("product_id") or expected_item.get("productId") or "")
            match = next((item for item in order_items if str(((item.get("product") or {}).get("id") or "")) == product_id), None)
            assert match is not None, f"expected latest order item with product_id={product_id}"
            if "quantity" in expected_item:
                actual_quantity = int(match.get("quantity") or 0)
                expected_quantity = int(expected_item.get("quantity") or 0)
                assert actual_quantity == expected_quantity, (
                    f"expected latest order quantity {expected_quantity} for product {product_id}, got {actual_quantity}"
                )
            if "selected_spec" in expected_item:
                actual_spec = str(match.get("selectedSpec") or "")
                expected_spec = str(expected_item.get("selected_spec") or "")
                assert actual_spec == expected_spec, (
                    f"expected latest order selectedSpec={expected_spec} for product {product_id}, got {actual_spec}"
                )

    @staticmethod
    def _validate_benchmark_events(expectations: list[Any], payload: Mapping[str, Any]) -> None:
        events = list(payload.get("events") or [])
        for expected_event in expectations:
            if not isinstance(expected_event, Mapping):
                continue
            event_type = str(expected_event.get("type") or "").strip()
            matcher = dict(expected_event.get("match") or {})
            assert event_type, "benchmark event expectation missing type"
            matched = False
            for event in events:
                if str(event.get("type") or "") != event_type:
                    continue
                if all(str(event.get(key) or "") == str(value or "") for key, value in matcher.items()):
                    matched = True
                    break
            suffix = f" with {matcher}" if matcher else ""
            assert matched, f"expected benchmark event {event_type}{suffix}"

    @staticmethod
    def _validate_benchmark_event_sequence(expectations: list[Any], payload: Mapping[str, Any]) -> None:
        events = list(payload.get("events") or [])
        cursor = 0
        for expected_event in expectations:
            if not isinstance(expected_event, Mapping):
                continue
            event_type = str(expected_event.get("type") or "").strip()
            matcher = dict(expected_event.get("match") or {})
            assert event_type, "benchmark event sequence expectation missing type"
            found_at = None
            for index in range(cursor, len(events)):
                event = dict(events[index] or {})
                if str(event.get("type") or "") != event_type:
                    continue
                if all(str(event.get(key) or "") == str(value or "") for key, value in matcher.items()):
                    found_at = index
                    break
            suffix = f" with {matcher}" if matcher else ""
            assert found_at is not None, f"expected benchmark event sequence item {event_type}{suffix}"
            cursor = found_at + 1

    @staticmethod
    def _validate_text_artifacts(controller: Any, expectations: list[Any], *, timeout: int) -> list[Mapping[str, Any]]:
        normalized: list[Mapping[str, Any]] = [
            dict(item)
            for item in expectations
            if isinstance(item, Mapping) and str(item.get("path") or "").strip()
        ]
        if not normalized:
            return []

        script = f"""python3 - <<'PY'
import json
from pathlib import Path

expectations = json.loads({json.dumps(json.dumps(normalized, ensure_ascii=False))})
results = []
for item in expectations:
    path = Path(str(item.get("path") or ""))
    if not path.is_file():
        raise SystemExit(f"TEXT_ARTIFACT_NOT_FOUND:{{path}}")
    actual = path.read_text(encoding=str(item.get("encoding") or "utf-8")).replace("\\r\\n", "\\n")
    result = {{"path": str(path), "bytes": len(actual.encode("utf-8"))}}
    if "equals" in item:
        expected = str(item.get("equals") or "").replace("\\r\\n", "\\n")
        if actual.rstrip("\\n") != expected.rstrip("\\n"):
            raise SystemExit(
                "TEXT_ARTIFACT_MISMATCH:"
                + str(path)
                + ":expected="
                + repr(expected)
                + ":actual="
                + repr(actual)
            )
    for needle in item.get("contains") or []:
        if str(needle) not in actual:
            raise SystemExit(f"TEXT_ARTIFACT_MISSING_TEXT:{{path}}:{{needle}}")
    results.append(result)
print(json.dumps(results, ensure_ascii=False))
PY"""
        result = controller.run_bash_script(script, timeout=timeout + 5)
        returncode = int(result.get("returncode", -1))
        output = str(result.get("output", "")).strip()
        if returncode != 0:
            raise AssertionError(output or f"text artifact validation failed with exit code {returncode}")
        return json.loads(output or "[]")
